//
//  Coffeesmodel.swift
//  Davaleba41v2
//
//  Created by konstantine gudushauri on 6/17/20.
//  Copyright © 2020 konstantine gudushauri. All rights reserved.
//

import Foundation
struct CoffeesModel {
    let coffees = ["Espresso","Cappuccino","Macciato","Mocha","Latte"]
}
